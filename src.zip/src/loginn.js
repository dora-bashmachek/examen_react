const Loginn =()=>{
    return(
        <div>
            <p> stranica registracii</p>
        </div>
    )
}
export default Loginn;