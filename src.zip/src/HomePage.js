const HomePage=()=>{
    return(
        <div>
            <input></input>
            <button> Click me </button>
        </div>
    )
}
export default HomePage;