import "./brands.css";
import Converse from "../converse/converse";
import Vans from "../vans/vans";
import Jordan from "../jordan/jordan";
import {Link} from 'react-router-dom'
const Brands  =()=> { 
  return( 
    <div>
      
    </div>
 )
}
export default Brands;











// import "./brands.css";
// const Brands  =()=> {
//           const data=[
//             {name:'Jordan'},
//             {name:'Converse'},
//             {name:'Vans'}
//           ]
//          const buttons=data.map(({name})=>{
//         // const active=props.filter===name;
//         // const classCss=active? 'btn btn-light': "btn btn-light-light";
//         return(
//             <button type="button"
//             key={name}>
//             {/* // onClick={()=>props.onFilterSelect(name)}
//             //     {label} */}
//             {name}
//             </button>
//             )
//         })
//         return(
//           <div className="brand">
//         <div className="button">
//             {buttons}
//         </div> 
//         </div>
//         )
// }
// export default Brands;



// import HomePage from './HomePage';
// import Loginn from './loginn';
// import {Routes, Route} from 'react-router-dom'
// import {Link} from 'react-router-dom'
      {/* <Routes> 
      <Route path="/" element={<HomePage/>}/> 
      <Route path="/login" element={<Loginn/>}/> 
      </Routes> 
      
      <ul>
        <li> <Link to="/">Home</Link></li>
        <li> <Link to="/login">login</Link></li>
      </ul> */}