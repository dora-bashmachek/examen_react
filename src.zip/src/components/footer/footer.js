import "./footer.css";
import {Component} from 'react';

class Footer extends Component {
    render(){
        return(
            <div className="line">
            <div className="foot">
                <h1>Thank you for making the right choice with us.</h1>
            </div>
            </div>
        )
    }
}

export default Footer;