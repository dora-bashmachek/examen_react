import "./vans.css";
import {Component} from 'react';

class Vans extends Component {
    render(){
        return(
            <div> Vans</div>
        )
    }
}

export default Vans;