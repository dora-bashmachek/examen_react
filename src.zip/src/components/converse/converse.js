import "./converse.css";
import {Component} from 'react';

class Converse extends Component {
    render(){
        return(
            <div>Converse</div>
        )
    }
}

export default Converse;