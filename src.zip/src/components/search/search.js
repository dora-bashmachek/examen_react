import "./search.css";
import {Component} from 'react';

class Search extends Component {
    render(){
        return(
            <div> hello </div>
        )
    }
}

export default Search;