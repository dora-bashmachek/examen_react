import "./jordan.css";
import {Component} from 'react';

class Jordan extends Component {
    render(){
        return(
            <div> Jordan </div>
        )
    }
}

export default Jordan;